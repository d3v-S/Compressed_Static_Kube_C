#include <stdlib.h>
#include <stdio.h>
#include "../include/apiClient.h"
#include "../include/list.h"
#include "../external/cJSON.h"
#include "../include/keyValuePair.h"


void
LogsAPI_logFileHandler(apiClient_t *apiClient, char * logpath );


void
LogsAPI_logFileListHandler(apiClient_t *apiClient);


